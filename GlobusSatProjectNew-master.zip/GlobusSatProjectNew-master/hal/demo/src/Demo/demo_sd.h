/*
 * demo_sd.h
 *
 *  Created on: 24 mrt. 2015
 *      Author: pbot
 */

#ifndef DEMO_DEMO_SD_H_
#define DEMO_DEMO_SD_H_

void DEMO_SD_Basic( int volID );
void DEMO_SD_FileTasks( int volID );
void DEMO_SD_StringFunc( void );

#endif /* DEMO_DEMO_SD_H_ */
