/*
 * demo_uart.h
 *
 *  Created on: 19 dec. 2014
 *      Author: pbot
 */

#ifndef DEMO_UART_H_
#define DEMO_UART_H_

void DEMO_UART_SetupVariablePacketTask(void);
void DEMO_UART_SetupUnknownPacketTask( void );

#endif /* DEMO_UART_H_ */
