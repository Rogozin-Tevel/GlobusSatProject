/*
 * USBdeviceTest.h
 *
 *  Created on: 19-Jun-2013
 *      Author: Akhil Piplani
 */

#ifndef USBDEVICETEST_H_
#define USBDEVICETEST_H_

#include <hal/boolean.h>

Boolean USBdeviceTest();

#endif /* USBDEVICETEST_H_ */
