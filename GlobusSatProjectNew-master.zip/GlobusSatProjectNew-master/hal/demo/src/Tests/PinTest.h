/*
 * PinTest.h
 *
 *  Created on: 26-Feb-2013
 *      Author: Akhil Piplani
 */

#ifndef PINTEST_H_
#define PINTEST_H_

Boolean PinTest();

#endif /* PINTEST_H_ */
