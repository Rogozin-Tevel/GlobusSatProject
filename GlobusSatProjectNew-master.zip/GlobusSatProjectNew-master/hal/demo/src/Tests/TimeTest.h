/*
 * TimeTest.h
 *
 *  Created on: 10 dec. 2014
 *      Author: malv
 */

#ifndef TIMETEST_H_
#define TIMETEST_H_

#include <hal/boolean.h>

Boolean TimeTest();

#endif /* TIMETEST_H_ */
