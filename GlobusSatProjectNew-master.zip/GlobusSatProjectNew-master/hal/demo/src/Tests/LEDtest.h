/*
 * LEDtest.h
 *
 *  Created on: 23-Jan-2013
 *      Author: Akhil Piplani
 */

#ifndef LEDTEST_H_
#define LEDTEST_H_

Boolean LEDtest();

#endif /* LEDTEST_H_ */
