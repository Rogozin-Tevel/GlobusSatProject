#ifndef CHECKSUMTEST_H
#define CHECKSUMTEST_H

#include <hal/boolean.h>

Boolean checksumTest(void);

#endif // CHECKSUMTEST_H
