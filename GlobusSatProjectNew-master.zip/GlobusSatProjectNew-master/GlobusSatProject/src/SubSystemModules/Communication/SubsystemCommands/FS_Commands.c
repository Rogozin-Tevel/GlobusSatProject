#include "FS_Commands.h"

int CMD_DeleteFileByTime(sat_packet_t *cmd)
{
	return 0;
}

int CMD_DeleteFilesOfType(sat_packet_t *cmd)
{
	return 0;
}

int CMD_DeleteFS(sat_packet_t *cmd)
{
	return 0;
}

int CMD_GetNumOfFilesInTimeRange(sat_packet_t *cmd)
{
	return 0;
}

int CMD_GetNumOfFilesByType(sat_packet_t *cmd)
{
	return 0;
}

int CMD_GetLastFS_Error(sat_packet_t *cmd)
{
	return 0;
}

int CMD_FreeSpace(sat_packet_t *cmd)
{
	return 0;
}

int CMD_GetFileLengthByTime(sat_packet_t *cmd)
{
	return 0;
}

int CMD_GetTimeOfLastElementInFile(sat_packet_t *cmd)
{
	return 0;
}

int CMD_GetTimeOfFirstElement(sat_packet_t *cmd)
{
	return 0;
}
