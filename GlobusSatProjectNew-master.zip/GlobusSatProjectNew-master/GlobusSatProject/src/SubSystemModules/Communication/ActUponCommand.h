
#ifndef ACTUPONCOMMAND_H_
#define ACTUPONCOMMAND_H_

#include "GlobalStandards.h"
#include "SatCommandHandler.h"

int ActUponCommand(sat_packet_t *cmd);

#endif /* ACTUPONCOMMAND_H_ */
