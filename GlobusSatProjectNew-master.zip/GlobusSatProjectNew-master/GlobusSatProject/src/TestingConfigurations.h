
#ifndef TESTINGCONFIGURATIONS_H_
#define TESTINGCONFIGURATIONS_H_

#define TESTING	// currently in testing mode
//#define TESTING_TRXVU_FRAME_LENGTH 1000

#define ISISEPS	// using the isisEPS subsystem
//#define GOMEPS	// using the GonEPS subsystem
//#define SET_EPS_CHANNELS // if we want to set the eps channels or not
#endif /* TESTINGCONFIGURATIONS_H_ */
