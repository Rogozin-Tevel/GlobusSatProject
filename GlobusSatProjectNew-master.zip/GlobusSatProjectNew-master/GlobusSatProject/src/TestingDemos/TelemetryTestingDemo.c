#include "TelemetryTestingDemo.h"

Boolean MainTelemetryTestBench()
{
	return FALSE;
}
