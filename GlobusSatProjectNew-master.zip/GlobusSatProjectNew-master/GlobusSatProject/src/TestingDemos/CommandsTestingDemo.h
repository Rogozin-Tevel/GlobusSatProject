
#ifndef COMMANDSTESTINGDEMO_H_
#define COMMANDSTESTINGDEMO_H_

#include "GlobalStandards.h"

Boolean MainCommandsTestBench();

#endif /* COMMANDSTESTINGDEMO_H_ */
