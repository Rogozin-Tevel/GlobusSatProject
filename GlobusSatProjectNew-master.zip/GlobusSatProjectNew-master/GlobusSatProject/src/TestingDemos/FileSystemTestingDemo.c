#include "FileSystemTestingDemo.h"
#include "GlobalStandards.h"

Boolean MainFileSystemTestBench()
{
	return FALSE;
}
