
#ifndef TELEMETRYTESTINGDEMO_H_
#define TELEMETRYTESTINGDEMO_H_

#include "GlobalStandards.h"

Boolean MainTelemetryTestBench();

#endif /* TELEMETRYTESTINGDEMO_H_ */
