/*
 * payload_CMD.h
 *
 *  Created on: Jun 22, 2019
 *      Author: Hoopoe3n
 */

#ifndef PAYLOAD_CMD_H_
#define PAYLOAD_CMD_H_

#include "../../COMM/GSC.h"
#include "../../Global/Global.h"

#endif /* PAYLOAD_CMD_H_ */
